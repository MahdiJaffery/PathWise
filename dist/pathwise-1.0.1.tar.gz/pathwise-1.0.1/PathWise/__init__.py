from .A_Star import A_Star
from .BFS import BFS
from .DFS import DFS
from .UCS import UCS